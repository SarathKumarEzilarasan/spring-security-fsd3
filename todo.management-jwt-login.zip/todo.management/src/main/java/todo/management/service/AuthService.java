package todo.management.service;

import todo.management.dto.JwtAuthResponse;
import todo.management.dto.LoginDto;
import todo.management.dto.RegisterDto;

public interface AuthService {
    String register(RegisterDto registerDto);
    JwtAuthResponse login(LoginDto loginDto);
}
