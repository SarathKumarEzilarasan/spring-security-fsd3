package todo.management.service.impl;

import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import todo.management.dto.ToDoDto;
import todo.management.entity.ToDo;
import todo.management.exception.ResourceNotFoundException;
import todo.management.repository.ToDoRepository;
import todo.management.service.ToDoService;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ToDoServiceImpl implements ToDoService {

    private ToDoRepository toDoRepository;
    private ModelMapper modelMapper;

    @Override
    public ToDoDto addToDo(ToDoDto toDoDto) {
        ToDo toDo = modelMapper.map(toDoDto, ToDo.class);
        ToDo savedToDo = toDoRepository.save(toDo);

        return modelMapper.map(savedToDo, ToDoDto.class);
    }

    @Override
    public ToDoDto getToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo", "id", id));
        return modelMapper.map(toDo, ToDoDto.class);
    }

    @Override
    public List<ToDoDto> getAllToDos() {
        List<ToDo> toDos = toDoRepository.findAll();
        return toDos.stream().map(todo -> modelMapper.map(todo, ToDoDto.class)).collect(Collectors.toList());
    }

    @Override
    public ToDoDto updatedToDo(ToDoDto toDoDto, Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo", "id", id));
        toDo.setTitle(toDoDto.getTitle());
        toDo.setDescription(toDoDto.getDescription());
        toDo.setCompleted(toDoDto.isCompleted());

        ToDo updatedTodo = toDoRepository.save(toDo);
        return modelMapper.map(updatedTodo, ToDoDto.class);
    }

    @Override
    public void deleteToDo(Long id) {
        ToDo existingTodo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo", "id", id));
        toDoRepository.deleteById(existingTodo.getId());
    }
}
