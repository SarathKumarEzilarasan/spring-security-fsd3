package todo.management.service;

import todo.management.dto.ToDoDto;

import java.util.List;

public interface ToDoService {

    ToDoDto addToDo(ToDoDto toDoDto);

    ToDoDto getToDo(Long id);

    List<ToDoDto> getAllToDos();

    ToDoDto updatedToDo(ToDoDto toDoDto, Long id);

    void deleteToDo(Long id);
}
