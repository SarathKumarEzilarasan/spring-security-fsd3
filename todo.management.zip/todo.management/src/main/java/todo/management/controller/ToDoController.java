package todo.management.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;
import todo.management.dto.LoginDto;
import todo.management.dto.ToDoDto;
import todo.management.security.JwtUtil;
import todo.management.service.ToDoService;

import java.util.List;

@RestController
@RequestMapping("api/todos")
@AllArgsConstructor
public class ToDoController {

    private ToDoService toDoService;
    private AuthenticationManager authenticationManager;
    private JwtUtil jwtUtil;

    @PostMapping("login")
    public ResponseEntity<String> addToDo(@RequestBody LoginDto loginDto) {
        UsernamePasswordAuthenticationToken token =
                new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword());
        authenticationManager.authenticate(token);
        String jwt = jwtUtil.generate(loginDto.getUsername());
        return ResponseEntity.ok(jwt);
    }

    @PostMapping
    public ResponseEntity<ToDoDto> addToDo(@RequestBody ToDoDto toDoDto) {
        ToDoDto savedToDoDto = toDoService.addToDo(toDoDto);
        return new ResponseEntity<>(savedToDoDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ToDoDto>> getAllToDos() {
        return new ResponseEntity<>(toDoService.getAllToDos(), HttpStatus.OK);
    }
}
