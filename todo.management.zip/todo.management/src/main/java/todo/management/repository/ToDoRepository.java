package todo.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import todo.management.entity.ToDo;

public interface ToDoRepository extends JpaRepository<ToDo,Long> {
}
